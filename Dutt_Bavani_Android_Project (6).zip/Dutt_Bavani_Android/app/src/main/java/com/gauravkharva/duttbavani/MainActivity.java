package com.gauravkharva.duttbavani;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Offline Gujarati Shri Dutt Bavani reader.
 * Three unnumbered verses appear per page. On the reading screen:
 * RIGHT swipe = NEXT page; LEFT swipe = PREVIOUS page (as requested).
 * The 5-reading and 52-reading checklists are separate and saved locally.
 */
public final class MainActivity extends Activity {
    private static final int VERSES = 52;
    private static final int PER_PAGE = 3;
    private static final int PAGES = (VERSES + PER_PAGE - 1) / PER_PAGE;
    private static final int HOME = 0, READER = 1, CHECKLIST = 2;
    private static final String PREFS = "dutt_bavani_reading_pages_v2";
    private static final int MAROON = 0xFF612F3D;
    private static final int DEEP = 0xFF3A2430;
    private static final int GOLD = 0xFFC18A42;
    private static final int BACKGROUND = 0xFFF9F3E9;
    private static final int WHITE = Color.WHITE;
    private static final int INK = 0xFF342C2A;
    private static final int MUTED = 0xFF75645D;
    private static final int GREEN = 0xFF287A58;
    private static final int PALE = 0xFFF3E6D6;
    private static final String CREDIT = "Developed By : Gaurav Kharva";

    private final String[] verses = new String[VERSES];
    private final ArrayList<TextView> activeVerseText = new ArrayList<>();
    private SharedPreferences preferences;
    private LinearLayout root;
    private int screen = HOME;
    private int page = 0;
    private int checklistGoal = 52;
    private int verseFontSize = 22;
    private long checkedFive;
    private long checkedFiftyTwo;
    private TextView progressLabel;
    private ProgressBar progressBar;
    private GestureDetector gesture;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(DEEP);
        getWindow().setNavigationBarColor(DEEP);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        checklistGoal = preferences.getInt("checklist_goal", 52) == 5 ? 5 : 52;
        checkedFive = preferences.getLong("completed_5", 0L) & ((1L << 5) - 1L);
        checkedFiftyTwo = preferences.getLong("completed_52", 0L) & ((1L << 52) - 1L);
        // Preserve any 52-reading progress recorded by the previous app version.
        if (!preferences.contains("completed_52")) {
            SharedPreferences old = getSharedPreferences("dutt_bavani_52_readings", MODE_PRIVATE);
            if (old.contains("completed_mask")) {
                checkedFiftyTwo = old.getLong("completed_mask", 0L) & ((1L << 52) - 1L);
                preferences.edit().putLong("completed_52", checkedFiftyTwo).apply();
            }
        }
        page = Math.max(0, Math.min(PAGES - 1, preferences.getInt("current_page", 0)));
        verseFontSize = Math.max(18, Math.min(30, preferences.getInt("font_sp", 22)));
        try {
            loadVerses();
        } catch (Exception problem) {
            new AlertDialog.Builder(this).setTitle("દત્ત બાવની")
                .setMessage("પાઠ ખોલવામાં સમસ્યા: " + problem.getMessage())
                .setCancelable(false).setPositiveButton("બંધ કરો", (d, w) -> finish()).show();
            return;
        }
        gesture = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onFling(MotionEvent down, MotionEvent up, float velocityX, float velocityY) {
                if (screen != READER || down == null || up == null) return false;
                float dx = up.getX() - down.getX();
                float dy = up.getY() - down.getY();
                if (Math.abs(dx) < dp(80) || Math.abs(dx) < Math.abs(dy) * 1.3f
                    || Math.abs(velocityX) < dp(220)) return false;
                if (root != null) root.post(() -> movePage(dx > 0 ? 1 : -1));
                return true;
            }
        });
        showHome();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (screen == READER && gesture != null && event.getPointerCount() == 1)
            gesture.onTouchEvent(event);
        return super.dispatchTouchEvent(event);
    }

    private void loadVerses() throws Exception {
        InputStream input = getAssets().open("dutt_bavani.txt");
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = input.read(buffer)) >= 0) output.write(buffer, 0, n);
        input.close();
        String source = new String(output.toByteArray(), StandardCharsets.UTF_8).replace("\r", "");
        String[] sections = source.trim().split("\\n\\s*\\n");
        if (sections.length != VERSES + 2)
            throw new Exception("Expected 52 passages; found " + (sections.length - 2));
        for (int i = 0; i < VERSES; i++) {
            String raw = sections[i + 1].trim();
            if (!raw.matches("(?s).*॥\\s*" + (i + 1) + "\\s*॥\\s*$"))
                throw new Exception("Passage " + (i + 1) + " is missing");
            // Keep the devotional double danda, remove only the numeric suffix.
            verses[i] = raw.replaceFirst("\\s*॥\\s*[0-9]+\\s*॥\\s*$", " ॥").trim();
        }
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
    private String gujarati(int n) {
        String english = Integer.toString(n), digits = "૦૧૨૩૪૫૬૭૮૯";
        StringBuilder local = new StringBuilder();
        for (char c : english.toCharArray()) local.append(digits.charAt(c - '0'));
        return local.toString();
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String content, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(content); t.setTextSize(size); t.setTextColor(color);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int left, int top, int right, int bottom) { v.setPadding(dp(left), dp(top), dp(right), dp(bottom)); }
    private void add(LinearLayout parent, View v) { parent.addView(v, new LinearLayout.LayoutParams(-1, -2)); }
    private void gap(LinearLayout parent, int height) { parent.addView(new View(this), new LinearLayout.LayoutParams(1, dp(height))); }
    private TextView action(String label, int background, int color, View.OnClickListener listener) {
        TextView v = text(label, 16, color, true); v.setGravity(Gravity.CENTER);
        v.setMinHeight(dp(48)); pad(v, 12, 11, 12, 11);
        v.setBackground(shape(background, 12)); v.setOnClickListener(listener);
        return v;
    }
    private ImageView image(int resourceId, int heightDp) {
        ImageView im = new ImageView(this);
        im.setImageResource(resourceId); im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        im.setAdjustViewBounds(true);
        im.setMinimumHeight(dp(heightDp));
        im.setContentDescription(resourceId == R.drawable.datt_opening
            ? "શ્રી દત્તાત્રેય ભગવાનનું ચિત્ર" : "દત્તાત્રેય ભગવાનનું ચિત્ર");
        return im;
    }
    private void initialize(int which) {
        screen = which;
        activeVerseText.clear();
        progressLabel = null; progressBar = null;
        root = column(); root.setBackgroundColor(BACKGROUND);
        setContentView(root);
    }
    private void header(String title, View.OnClickListener back) {
        LinearLayout bar = row(); bar.setBackgroundColor(DEEP); pad(bar, 12, 13, 14, 13);
        if (back != null) {
            TextView backView = text("‹", 33, Color.WHITE, false);
            backView.setGravity(Gravity.CENTER); pad(backView, 8, 0, 15, 0);
            backView.setContentDescription("મુખ્ય પાને પાછા");
            backView.setOnClickListener(back); bar.addView(backView);
        }
        TextView label = text(title, 23, Color.WHITE, true);
        label.setGravity(Gravity.CENTER);
        bar.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
        add(root, bar);
    }
    private ScrollView scrollingBody() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return scroll;
    }
    private void creditFooter() {
        TextView developer = text(CREDIT, 14, MAROON, true);
        developer.setGravity(Gravity.CENTER);
        pad(developer, 8, 10, 8, 11);
        developer.setBackgroundColor(0xFFF2E8DB);
        add(root, developer);
    }

    private void showHome() {
        initialize(HOME);
        header("॥ શ્રી દત્ત બાવની ॥", null);
        ScrollView scroll = scrollingBody();
        LinearLayout body = column(); pad(body, 20, 19, 20, 22);
        scroll.addView(body);
        TextView author = text("શ્રી રંગ અવધૂત સ્વામિ વિરચિત", 17, MAROON, true);
        author.setGravity(Gravity.CENTER); add(body, author); gap(body, 11);
        ImageView picture = image(R.drawable.datt_opening, 300);
        picture.setBackground(shape(Color.WHITE, 19)); picture.setClipToOutline(true);
        body.addView(picture, new LinearLayout.LayoutParams(-1, dp(360)));
        gap(body, 19);
        TextView invocation = text("॥ અવધૂત ચિંતન શ્રી ગુરુદેવ દત્ત ॥", 19, MAROON, true);
        invocation.setGravity(Gravity.CENTER); add(body, invocation);
        gap(body, 18);
        add(body, action("પાઠ શરૂ કરો  ›", GREEN, Color.WHITE, v -> showReading()));
        gap(body, 11);
        add(body, action("૫ / ૫૨ વાર પાઠ ચેકલિસ્ટ", PALE, MAROON, v -> showChecklist()));
        gap(body, 16);
        TextView hint = text("દરેક પાને ૩ પંક્તિ-યુગ્મના પાઠ. જમણે સ્વાઇપ = આગળ, ડાબે સ્વાઇપ = પાછળ.", 14, MUTED, false);
        hint.setGravity(Gravity.CENTER); add(body, hint);
        creditFooter();
    }

    private void movePage(int step) {
        int destination = page + step;
        if (destination < 0 || destination >= PAGES) return;
        page = destination;
        preferences.edit().putInt("current_page", page).apply();
        showReading();
    }
    private void fontChange(int amount) {
        verseFontSize = Math.max(18, Math.min(30, verseFontSize + amount));
        preferences.edit().putInt("font_sp", verseFontSize).apply();
        for (TextView label : activeVerseText) label.setTextSize(verseFontSize);
    }
    private void showReading() {
        initialize(READER);
        header("શ્રી દત્ત બાવની", v -> showHome());
        LinearLayout navigationTop = row(); pad(navigationTop, 16, 8, 16, 8);
        TextView number = text("પાનું " + gujarati(page + 1) + " / " + gujarati(PAGES), 17, MAROON, true);
        navigationTop.addView(number, new LinearLayout.LayoutParams(0, -2, 1));
        TextView smaller = action("A−", PALE, MAROON, v -> fontChange(-2));
        smaller.setMinHeight(dp(38)); navigationTop.addView(smaller, new LinearLayout.LayoutParams(dp(55), -2));
        TextView larger = action("A+", PALE, MAROON, v -> fontChange(2));
        larger.setMinHeight(dp(38));
        LinearLayout.LayoutParams plus = new LinearLayout.LayoutParams(dp(55), -2);
        plus.setMargins(dp(6), 0, 0, 0); navigationTop.addView(larger, plus);
        add(root, navigationTop);

        ScrollView scroll = scrollingBody();
        LinearLayout body = column(); pad(body, 16, 12, 16, 24);
        scroll.addView(body);
        LinearLayout banner = row();
        banner.setBackground(shape(0xFFFFFBF2, 15)); pad(banner, 15, 9, 12, 9);
        LinearLayout heading = column();
        TextView title = text("શ્રી દત્ત બાવની", 23, MAROON, true); add(heading, title);
        gap(heading, 4);
        TextView author = text("શ્રી રંગ અવધૂત સ્વામિ વિરચિત", 12, MUTED, false); add(heading, author);
        banner.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        ImageView corner = image(R.drawable.datt_corner, 94);
        corner.setBackground(shape(WHITE, 10)); corner.setClipToOutline(true);
        banner.addView(corner, new LinearLayout.LayoutParams(dp(96), dp(96)));
        add(body, banner); gap(body, 13);

        int first = page * PER_PAGE;
        for (int n = first; n < Math.min(VERSES, first + PER_PAGE); n++) {
            LinearLayout card = column(); pad(card, 16, 19, 16, 19);
            card.setBackground(shape(WHITE, 15));
            TextView verse = text(verses[n], verseFontSize, INK, false);
            verse.setGravity(Gravity.CENTER);
            verse.setLineSpacing(dp(6), 1.11f);
            verse.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY);
            verse.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
            verse.setTextIsSelectable(false);
            add(card, verse); activeVerseText.add(verse);
            add(body, card); gap(body, 12);
        }
        if (page == PAGES - 1) {
            TextView ending = text("॥ અવધૂત ચિંતન શ્રી ગુરુદેવ દત્ત ॥", 19, MAROON, true);
            ending.setGravity(Gravity.CENTER); add(body, ending); gap(body, 17);
            add(body, action("✓  પૂર્ણ પાઠ નોંધો", GREEN, WHITE, v -> recordReading()));
            gap(body, 10);
        }

        LinearLayout nav = row(); pad(nav, 10, 10, 10, 10); nav.setBackgroundColor(WHITE);
        TextView previous = action("‹  પાછલું", PALE, MAROON, v -> movePage(-1));
        previous.setEnabled(page > 0); previous.setAlpha(page > 0 ? 1f : .35f);
        nav.addView(previous, new LinearLayout.LayoutParams(0, -2, 1));
        TextView checklist = action("✓", PALE, MAROON, v -> showChecklist());
        checklist.setContentDescription("પાઠ ચેકલિસ્ટ");
        LinearLayout.LayoutParams middle = new LinearLayout.LayoutParams(dp(50), -2);
        middle.setMargins(dp(7), 0, dp(7), 0); nav.addView(checklist, middle);
        TextView next = action("આગળ  ›", GREEN, WHITE, v -> movePage(1));
        next.setEnabled(page < PAGES - 1); next.setAlpha(page < PAGES - 1 ? 1f : .35f);
        nav.addView(next, new LinearLayout.LayoutParams(0, -2, 1));
        add(root, nav);
        creditFooter();
    }

    private int completed() { return Long.bitCount(checklistGoal == 5 ? checkedFive : checkedFiftyTwo); }
    private boolean isChecked(int i) { return ((checklistGoal == 5 ? checkedFive : checkedFiftyTwo) & (1L << i)) != 0; }
    private void setChecked(int i, boolean checked) {
        long bit = 1L << i;
        if (checklistGoal == 5) checkedFive = checked ? checkedFive | bit : checkedFive & ~bit;
        else checkedFiftyTwo = checked ? checkedFiftyTwo | bit : checkedFiftyTwo & ~bit;
        preferences.edit().putLong("completed_5", checkedFive)
            .putLong("completed_52", checkedFiftyTwo).apply();
        refreshProgress();
    }
    private void switchGoal(int goal) {
        if (checklistGoal == goal) return;
        checklistGoal = goal;
        preferences.edit().putInt("checklist_goal", goal).apply();
        showChecklist();
    }
    private void refreshProgress() {
        if (progressLabel != null)
            progressLabel.setText("પૂર્ણ થયેલા પાઠ: " + gujarati(completed()) + " / " + gujarati(checklistGoal));
        if (progressBar != null) {
            progressBar.setMax(checklistGoal);
            progressBar.setProgress(completed());
        }
    }
    private void showChecklist() {
        initialize(CHECKLIST);
        header("પાઠની ચેકલિસ્ટ", v -> showHome());
        ScrollView scroll = scrollingBody();
        LinearLayout body = column(); pad(body, 16, 17, 16, 24); scroll.addView(body);
        TextView heading = text("કેટલી વાર પાઠ કરવો છે?", 20, MAROON, true);
        heading.setGravity(Gravity.CENTER); add(body, heading); gap(body, 13);
        LinearLayout options = row();
        TextView five = action("૫ વાર", checklistGoal == 5 ? GREEN : PALE,
            checklistGoal == 5 ? WHITE : MAROON, v -> switchGoal(5));
        TextView fiftyTwo = action("૫૨ વાર", checklistGoal == 52 ? GREEN : PALE,
            checklistGoal == 52 ? WHITE : MAROON, v -> switchGoal(52));
        options.addView(five, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams optionEnd = new LinearLayout.LayoutParams(0, -2, 1);
        optionEnd.setMargins(dp(10), 0, 0, 0); options.addView(fiftyTwo, optionEnd);
        add(body, options); gap(body, 17);
        LinearLayout summary = column(); summary.setBackground(shape(WHITE, 15));
        pad(summary, 16, 16, 16, 16);
        progressLabel = text("", 21, MAROON, true); progressLabel.setGravity(Gravity.CENTER);
        add(summary, progressLabel); gap(summary, 11);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setProgressTintList(ColorStateList.valueOf(GREEN));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(PALE));
        add(summary, progressBar); gap(summary, 11);
        TextView help = text("દરેક ચેકબોક્સ આખી દત્ત બાવનીનો એક સંપૂર્ણ પાઠ દર્શાવે છે.", 15, MUTED, false);
        help.setGravity(Gravity.CENTER); add(summary, help);
        add(body, summary); refreshProgress(); gap(body, 13);

        int columns = checklistGoal == 5 ? 2 : 4;
        for (int rowIndex = 0; rowIndex < (checklistGoal + columns - 1) / columns; rowIndex++) {
            LinearLayout items = row();
            for (int c = 0; c < columns; c++) {
                int index = rowIndex * columns + c;
                if (index >= checklistGoal) {
                    items.addView(new View(this), new LinearLayout.LayoutParams(0, dp(52), 1));
                    continue;
                }
                CheckBox tick = new CheckBox(this);
                tick.setText(gujarati(index + 1)); tick.setTextSize(17); tick.setTextColor(INK);
                tick.setGravity(Gravity.CENTER_VERTICAL); tick.setMinHeight(dp(54));
                tick.setContentDescription("પૂર્ણ થયેલો પાઠ " + gujarati(index + 1));
                tick.setButtonTintList(new ColorStateList(
                    new int[][] { new int[]{android.R.attr.state_checked}, new int[]{} },
                    new int[] { GREEN, MAROON }));
                tick.setBackground(shape(isChecked(index) ? 0xFFE0F1E7 : WHITE, 11));
                pad(tick, 6, 6, 2, 6); tick.setChecked(isChecked(index));
                final int selected = index;
                tick.setOnCheckedChangeListener((v, checked) -> {
                    setChecked(selected, checked);
                    tick.setBackground(shape(checked ? 0xFFE0F1E7 : WHITE, 11));
                    if (completed() == checklistGoal) completionNotice();
                });
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
                params.setMargins(dp(3), dp(3), dp(3), dp(3)); items.addView(tick, params);
            }
            add(body, items);
        }
        gap(body, 19);
        add(body, action("પાઠ વાંચો", GREEN, WHITE, v -> showReading()));
        gap(body, 10);
        add(body, action("↺  રીસેટ કરો", 0xFFF1DCDD, 0xFF9A293D, v -> confirmReset()));
        gap(body, 12);
        TextView save = text("૫ અને ૫૨ વારની ચેકલિસ્ટ અલગ-અલગ સેવ થાય છે. રીસેટ માત્ર પસંદ કરેલી ચેકલિસ્ટનું થાય છે.", 13, MUTED, false);
        save.setGravity(Gravity.CENTER); add(body, save);
        creditFooter();
    }

    private void recordReading() {
        for (int i = 0; i < checklistGoal; i++) {
            if (!isChecked(i)) {
                setChecked(i, true);
                if (completed() == checklistGoal) completionNotice();
                else new AlertDialog.Builder(this).setTitle("પાઠ નોંધાયો ✓")
                    .setMessage(gujarati(completed()) + " / " + gujarati(checklistGoal) + " પૂર્ણ")
                    .setPositiveButton("ફરીથી વાંચો", (d, which) -> { page = 0; preferences.edit().putInt("current_page", 0).apply(); showReading(); })
                    .setNegativeButton("ચેકલિસ્ટ જુઓ", (d, which) -> showChecklist()).show();
                return;
            }
        }
        completionNotice();
    }
    private void confirmReset() {
        final int target = checklistGoal;
        new AlertDialog.Builder(this).setTitle("ચેકલિસ્ટ રીસેટ કરવી છે?")
            .setMessage(gujarati(target) + " વખતની ચેકલિસ્ટના બધા ચેકમાર્ક દૂર થશે. ચાલુ સ્થિતિ પાછી લાવી શકાશે નહીં.")
            .setNegativeButton("રદ કરો", null)
            .setPositiveButton("હા, રીસેટ કરો", (d, which) -> {
                if (target == 5) checkedFive = 0L; else checkedFiftyTwo = 0L;
                preferences.edit().putLong("completed_5", checkedFive)
                    .putLong("completed_52", checkedFiftyTwo).apply();
                showChecklist();
                Toast.makeText(this, "ચેકલિસ્ટ રીસેટ થઈ ગઈ", Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void completionNotice() {
        new AlertDialog.Builder(this).setTitle("🙏 પાઠ પૂર્ણ!")
            .setMessage(gujarati(checklistGoal) + " વખતનો પાઠ પૂર્ણ થયો! અવધૂત ચિંતન શ્રી ગુરુદેવ દત્ત.")
            .setPositiveButton("બરાબર", null).show();
    }
    @Override public void onBackPressed() {
        if (screen != HOME) showHome(); else super.onBackPressed();
    }
}
