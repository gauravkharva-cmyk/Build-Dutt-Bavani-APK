# શ્રી દત્ત બાવની — Android reader (Version 2)

**Developed By : Gaurav Kharva**

Offline Android application containing all 52 Gujarati verses of the Dutt Bavani exactly as supplied by the user, other than removing their visible numerical suffixes on reading pages.

## App screens and behavior

- **Opening screen:** large `1st Page.png` devotional artwork of Dattatreya, app title, start button, checklist button and developer credit.
- **Reading screen:** 3 unnumbered verses per page; 18 pages in total, with the final page containing verse 52 and the concluding invocation. Original Gujarati script is rendered using Android TextViews (not images, to prevent cropped letters). The other supplied picture (with cow and dogs) appears in the upper-right corner of every reading page. An always-visible footer says `Developed By : Gaurav Kharva`.
- **Gestures requested:** swipe RIGHT to go to the NEXT page; swipe LEFT to go to the PREVIOUS page. Next and Previous buttons also appear below each reading page. Pages scroll vertically if needed to display all 3 verses fully, especially when the font is enlarged.
- **Font size:** A- / A+ adjustable from 18sp through 30sp. This setting and the last-read page are remembered.
- **Checklist:** choose either **5 full readings** or **52 full readings**. The checklists are *separate*, can be checked or unchecked manually, automatically save between app launches, and show the appropriate progress counter. Existing 52-reading progress from the previous app version is migrated automatically if present. A complete-reading button appears on the final reading page to mark one full reading for the currently selected goal.
- **Reset:** reset only the selected checklist after a confirmation prompt.
- **Offline:** no INTERNET permission and no network resources.

## Contents

- `app/src/main/assets/dutt_bavani.txt`: original user-supplied Gujarati text with verse numbers retained as source data; numeric suffixes are removed at display time.
- `app/src/main/res/drawable-nodpi/datt_opening.png`: user-supplied *1st Page.png* cover image.
- `app/src/main/res/drawable-nodpi/datt_corner.jpg`: user-supplied *images.jfif* artwork.
- `.github/workflows/build-dutt-bavani.yml`: GitHub Actions build source (included for reference).

## Build APK with GitHub Actions

This ZIP has one top-level folder called `Dutt_Bavani_Android`.

1. Create a GitHub repository for the app.
2. Upload **exactly one** ZIP named `Dutt_Bavani_Android_Project.zip` (or an uploader-added numbered suffix) into the repository root.
3. In the repository, create `.github/workflows/build-dutt-bavani.yml` by copying the separate workflow file supplied with this project (it is also inside the source ZIP).
4. Commit. In **Actions**, open **Build Dutt Bavani APK**. Push or `Run workflow` starts a build.
5. On success download the **Dutt-Bavani-APK** artifact and extract `app-debug.apk`.

Requires Android SDK platform 35, Android Gradle Plugin 8.6.1, Gradle 8.9 and JDK 17. Android 6.0+ supported.

**Note:** This is an Android Studio / Gradle *source project*, not a pre-compiled APK. A full Android build and installation test must still be performed in an Android development environment.
