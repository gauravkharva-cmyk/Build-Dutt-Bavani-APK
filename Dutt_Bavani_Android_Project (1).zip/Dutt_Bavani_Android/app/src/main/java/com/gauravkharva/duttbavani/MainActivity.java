package com.gauravkharva.duttbavani;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Offline Gujarati Dutt Bavani application.
 * The 52 verses come directly from the user-supplied text (no PDF/image rendering).
 * The 52 checklist boxes count COMPLETED FULL RECITATIONS, not individual verses.
 */
public final class MainActivity extends Activity {
    private static final int TOTAL = 52;
    private static final int MAROON = 0xFF612F3D;
    private static final int DEEP = 0xFF3A2430;
    private static final int GOLD = 0xFFF0C47D;
    private static final int BG = 0xFFF9F3E9;
    private static final int INK = 0xFF342C2A;
    private static final int MUTED = 0xFF71645F;
    private static final int GREEN = 0xFF287A58;
    private static final int PALE = 0xFFF1E5D5;
    private static final String PREFS = "dutt_bavani_52_readings";

    private final String[] verses = new String[TOTAL];
    private final ArrayList<TextView> verseLabels = new ArrayList<>();
    private SharedPreferences preferences;
    private long checkedMask;
    private int verseSize;
    private boolean showingChecklist = false;
    private TextView countLabel;
    private ProgressBar progressBar;
    private TextView checklistSummary;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(DEEP);
        getWindow().setNavigationBarColor(DEEP);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        checkedMask = preferences.getLong("completed_mask", 0L) & ((1L << TOTAL) - 1L);
        verseSize = Math.max(18, Math.min(32, preferences.getInt("font_size_sp", 22)));
        try {
            readUserText();
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                .setTitle("દત્ત બાવની ખોલી શકાઈ નથી")
                .setMessage("પાઠની માહિતી ઉપલબ્ધ નથી: " + e.getMessage())
                .setCancelable(false)
                .setPositiveButton("બંધ કરો", (d, which) -> finish()).show();
            return;
        }
        showScreen(false);
    }

    private void readUserText() throws Exception {
        InputStream stream = getAssets().open("dutt_bavani.txt");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] part = new byte[4096];
        int bytes;
        while ((bytes = stream.read(part)) != -1) buffer.write(part, 0, bytes);
        stream.close();
        String source = new String(buffer.toByteArray(), StandardCharsets.UTF_8).replace("\r", "");
        String[] blocks = source.trim().split("\\n\\s*\\n");
        if (blocks.length != TOTAL + 2) throw new Exception("Expected 52 verses, got " + (blocks.length - 2));
        for (int i = 0; i < TOTAL; i++) {
            String verse = blocks[i + 1].trim();
            if (!verse.contains("॥ " + (i + 1) + "॥")) {
                throw new Exception("Incorrect verse number " + (i + 1));
            }
            verses[i] = verse;
        }
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private String gujarati(int n) {
        String source = Integer.toString(n), western = "0123456789", local = "૦૧૨૩૪૫૬૭૮૯";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < source.length(); i++) result.append(local.charAt(western.indexOf(source.charAt(i))));
        return result.toString();
    }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private TextView text(String content, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(content);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void padding(View view, int left, int top, int right, int bottom) {
        view.setPadding(dp(left), dp(top), dp(right), dp(bottom));
    }
    private void append(LinearLayout to, View child) {
        to.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }
    private void spacer(LinearLayout to, int height) {
        View v = new View(this);
        to.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private TextView button(String title, int fillColor, int textColor, View.OnClickListener action) {
        TextView t = text(title, 16, textColor, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(48));
        padding(t, 13, 12, 13, 12);
        t.setBackground(background(fillColor, 12));
        t.setOnClickListener(action);
        return t;
    }
    private int completed() { return Long.bitCount(checkedMask); }
    private void persist() { preferences.edit().putLong("completed_mask", checkedMask).apply(); }
    private boolean isChecked(int index) { return (checkedMask & (1L << index)) != 0; }

    private void showScreen(boolean checklist) {
        showingChecklist = checklist;
        verseLabels.clear();
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout header = column();
        header.setBackgroundColor(MAROON);
        padding(header, 18, 16, 18, 14);
        TextView title = text("॥ શ્રી દત્ત બાવની ॥", 27, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        append(header, title);
        spacer(header, 3);
        TextView author = text("શ્રી રંગ અવધૂત સ્વામિ વિરચિત", 13, 0xFFFFE7C4, false);
        author.setGravity(Gravity.CENTER);
        append(header, author);
        spacer(header, 12);

        countLabel = text("", 17, Color.WHITE, true);
        countLabel.setGravity(Gravity.CENTER);
        append(header, countLabel);
        spacer(header, 9);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(TOTAL);
        progressBar.setProgressTintList(ColorStateList.valueOf(GOLD));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF886473));
        append(header, progressBar);
        refreshProgress();
        spacer(header, 12);
        LinearLayout tabs = row();
        TextView readTab = button("પાઠ વાંચો", !checklist ? 0xFFFFE8C4 : 0xFF804B5B,
                                  !checklist ? MAROON : Color.WHITE, v -> showScreen(false));
        TextView listTab = button("૫૨ વાર ચેકલિસ્ટ", checklist ? 0xFFFFE8C4 : 0xFF804B5B,
                                  checklist ? MAROON : Color.WHITE, v -> showScreen(true));
        LinearLayout.LayoutParams tabParams = new LinearLayout.LayoutParams(0, -2, 1);
        tabParams.setMargins(dp(3), 0, dp(3), 0);
        tabs.addView(readTab, tabParams);
        LinearLayout.LayoutParams tabParams2 = new LinearLayout.LayoutParams(0, -2, 1);
        tabParams2.setMargins(dp(3), 0, dp(3), 0);
        tabs.addView(listTab, tabParams2);
        append(header, tabs);
        append(root, header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(true);
        LinearLayout body = column();
        padding(body, 16, 19, 16, 22);
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (checklist) renderChecklist(body); else renderReading(body);
    }

    private void refreshProgress() {
        int total = completed();
        if (countLabel != null) countLabel.setText("પૂર્ણ થયેલા પાઠ: " + gujarati(total) + " / ૫૨");
        if (progressBar != null) progressBar.setProgress(total);
        if (checklistSummary != null) checklistSummary.setText(total == TOTAL
            ? "તમારા તમામ ૫૨ પાઠ પૂર્ણ થયા છે!"
            : "હજુ " + gujarati(TOTAL - total) + " પાઠ બાકી છે.");
    }

    private void renderReading(LinearLayout body) {
        TextView introduction = text("શ્રી દત્ત બાવની", 24, MAROON, true);
        introduction.setGravity(Gravity.CENTER);
        append(body, introduction);
        spacer(body, 4);
        TextView attribution = text("[શ્રી રંગ અવધૂત સ્વામિ વિરચિત શ્રી દત્તભવાની]", 14, MUTED, false);
        attribution.setGravity(Gravity.CENTER);
        append(body, attribution);
        spacer(body, 15);

        LinearLayout adjust = row();
        TextView guide = text("અક્ષરનું કદ", 15, INK, true);
        adjust.addView(guide, new LinearLayout.LayoutParams(0, -2, 1));
        TextView minus = button("A−", PALE, MAROON, v -> resizeFont(-2));
        TextView plus = button("A+", PALE, MAROON, v -> resizeFont(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(66), -2);
        lp.setMargins(dp(5), 0, 0, 0);
        adjust.addView(minus, lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(dp(66), -2);
        lp2.setMargins(dp(5), 0, 0, 0);
        adjust.addView(plus, lp2);
        append(body, adjust);
        spacer(body, 12);

        for (int i = 0; i < TOTAL; i++) {
            LinearLayout card = column();
            card.setBackground(background(Color.WHITE, 15));
            padding(card, 15, 14, 15, 16);
            TextView indexText = text("શ્લોક " + gujarati(i + 1), 13, GREEN, true);
            indexText.setGravity(Gravity.CENTER);
            append(card, indexText);
            spacer(card, 7);
            TextView verse = text(verses[i], verseSize, INK, false);
            verse.setGravity(Gravity.CENTER);
            verse.setLineSpacing(dp(5), 1.12f);
            verse.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY);
            verse.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
            verse.setTextIsSelectable(true);
            append(card, verse);
            verseLabels.add(verse);
            append(body, card);
            spacer(body, 10);
        }
        spacer(body, 4);
        TextView closing = text("॥ અવધૂત ચિંતન શ્રી ગુરુદેવ દત્ત ॥", 22, MAROON, true);
        closing.setGravity(Gravity.CENTER);
        closing.setLineSpacing(dp(5), 1.15f);
        append(body, closing);
        spacer(body, 23);
        TextView completedButton = button("✓  આખો પાઠ પૂર્ણ થયો — ૧ વાર નોંધો", GREEN, Color.WHITE,
                                          v -> recordOneReading());
        append(body, completedButton);
        spacer(body, 10);
        TextView seeChecklist = button("૫૨ પાઠની ચેકલિસ્ટ જુઓ  ›", PALE, MAROON,
                                       v -> showScreen(true));
        append(body, seeChecklist);
        appendCredit(body);
    }

    private void resizeFont(int amount) {
        verseSize = Math.max(18, Math.min(32, verseSize + amount));
        preferences.edit().putInt("font_size_sp", verseSize).apply();
        for (TextView t : verseLabels) t.setTextSize(verseSize);
    }

    private void recordOneReading() {
        if (completed() == TOTAL) {
            new AlertDialog.Builder(this).setTitle("૫૨ પાઠ પૂર્ણ")
                .setMessage("તમારા બધા ૫૨ પાઠ પહેલેથી પૂર્ણ થયા છે. નવો આરંભ કરવા રીસેટ કરો.")
                .setPositiveButton("બરાબર", null).show();
            return;
        }
        for (int i = 0; i < TOTAL; i++) {
            if (!isChecked(i)) {
                checkedMask |= (1L << i);
                persist();
                refreshProgress();
                Toast.makeText(this, "પાઠ " + gujarati(i + 1) + " પૂર્ણ નોંધાયો", Toast.LENGTH_LONG).show();
                if (completed() == TOTAL) completedAlert();
                return;
            }
        }
    }

    private void renderChecklist(LinearLayout body) {
        LinearLayout instructions = column();
        padding(instructions, 17, 17, 17, 17);
        instructions.setBackground(background(Color.WHITE, 15));
        TextView heading = text("૫૨ વાર પાઠ ચેકલિસ્ટ", 23, MAROON, true);
        heading.setGravity(Gravity.CENTER);
        append(instructions, heading);
        spacer(instructions, 8);
        TextView explanation = text("દરેક વખતે સંપૂર્ણ દત્ત બાવની વાંચી લીધા પછી તે પાઠની સામે ✓ કરો. આ ચેકલિસ્ટમાં ૫૨ શ્લોક નહીં, પરંતુ સંપૂર્ણ પાઠના ૫૨ વખતની ગણતરી થાય છે.", 16, MUTED, false);
        explanation.setLineSpacing(dp(4), 1.09f);
        append(instructions, explanation);
        spacer(instructions, 12);
        checklistSummary = text("", 17, GREEN, true);
        checklistSummary.setGravity(Gravity.CENTER);
        append(instructions, checklistSummary);
        append(body, instructions);
        spacer(body, 15);

        for (int rowIndex = 0; rowIndex < 13; rowIndex++) {
            LinearLayout r = row();
            for (int colIndex = 0; colIndex < 4; colIndex++) {
                final int at = rowIndex * 4 + colIndex;
                CheckBox checkbox = new CheckBox(this);
                checkbox.setText(gujarati(at + 1));
                checkbox.setTextSize(16);
                checkbox.setTextColor(INK);
                checkbox.setGravity(Gravity.CENTER_VERTICAL);
                checkbox.setMinHeight(dp(55));
                checkbox.setContentDescription("પાઠ " + (at + 1) + " પૂર્ણ થયો");
                checkbox.setButtonTintList(new ColorStateList(
                    new int[][] { new int[]{android.R.attr.state_checked}, new int[]{} },
                    new int[]{GREEN, MAROON}));
                checkbox.setBackground(background(isChecked(at) ? 0xFFE0F1E7 : Color.WHITE, 11));
                padding(checkbox, 6, 5, 3, 5);
                checkbox.setChecked(isChecked(at));
                checkbox.setOnCheckedChangeListener((button, checked) -> {
                    if (checked) checkedMask |= 1L << at;
                    else checkedMask &= ~(1L << at);
                    checkbox.setBackground(background(checked ? 0xFFE0F1E7 : Color.WHITE, 11));
                    persist();
                    refreshProgress();
                    if (completed() == TOTAL) completedAlert();
                });
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
                p.setMargins(dp(3), dp(3), dp(3), dp(3));
                r.addView(checkbox, p);
            }
            append(body, r);
        }
        spacer(body, 21);
        TextView read = button("પાઠ વાંચો  ›", GREEN, Color.WHITE, v -> showScreen(false));
        append(body, read);
        spacer(body, 10);
        TextView reset = button("↺  ચેકલિસ્ટ રીસેટ કરો", 0xFFF1DCDD, 0xFF9A293D, v -> confirmReset());
        append(body, reset);
        spacer(body, 5);
        TextView resetHelp = text("રીસેટ કરતાં બધા ૫૨ ચેકમાર્ક દૂર થશે. પહેલાં પુષ્ટિ પૂછવામાં આવશે.", 13, MUTED, false);
        resetHelp.setGravity(Gravity.CENTER);
        append(body, resetHelp);
        appendCredit(body);
        refreshProgress();
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
            .setTitle("ચેકલિસ્ટ રીસેટ કરવી છે?")
            .setMessage("બધા ૫૨ પાઠના ચેકમાર્ક દૂર થશે અને ગણતરી ૦ / ૫૨ થશે. આ ફેરફાર પાછો લઈ શકાશે નહીં.")
            .setNegativeButton("રદ કરો", null)
            .setPositiveButton("હા, રીસેટ કરો", (dialog, which) -> {
                checkedMask = 0L;
                persist();
                showScreen(true);
                Toast.makeText(this, "ચેકલિસ્ટ રીસેટ થઈ ગઈ", Toast.LENGTH_SHORT).show();
            }).show();
    }

    private void completedAlert() {
        new AlertDialog.Builder(this)
            .setTitle("🙏 ૫૨ પાઠ પૂર્ણ!")
            .setMessage("તમારા દત્ત બાવનીના બધા ૫૨ પાઠ પૂર્ણ થયા. અવધૂત ચિંતન શ્રી ગુરુદેવ દત્ત!")
            .setPositiveButton("જય ગુરુદેવ દત્ત", null).show();
    }

    private void appendCredit(LinearLayout body) {
        spacer(body, 28);
        TextView credit = text("Developed By : Gaurav Kharva", 15, MAROON, true);
        credit.setGravity(Gravity.CENTER);
        append(body, credit);
        spacer(body, 14);
    }

    @Override public void onBackPressed() {
        if (showingChecklist) showScreen(false);
        else super.onBackPressed();
    }
}
