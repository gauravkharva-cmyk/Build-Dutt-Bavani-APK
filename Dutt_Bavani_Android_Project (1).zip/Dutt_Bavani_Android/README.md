# શ્રી દત્ત બાવની — Android (Gujarati)

Offline Android app for reading Dutt Bavani and tracking **52 complete recitations**.

## Features
- All 52 Gujarati verses, reproduced from the text provided by the user.
- One long, scrollable reading page, with readable selectable Gujarati text and A−/A+ font adjustment.
- Independent **52-checkmark recitation tracker**. Each checkmark represents **one complete reading of the entire Dutt Bavani**, not a single verse.
- "આખો પાઠ પૂર્ણ થયો — ૧ વાર નોંધો" button marks the first incomplete checklist item.
- Checklist saves automatically using Android SharedPreferences; no sign-in or Internet permissions.
- Reset button with a confirmation dialog to clear all 52 checkmarks.
- On-screen credit: **Developed By : Gaurav Kharva**.
- Android 6.0+; Java 17; Android Gradle Plugin 8.6.1; Gradle 8.9; compile SDK 35.

## Open in Android Studio
Open the `Dutt_Bavani_Android` folder, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Build with GitHub Actions without Android Studio
The workflow at `.github/workflows/build-dutt-bavani.yml` assumes the project ZIP is committed in your repo's **root** and named `Dutt_Bavani_Android_Project.zip` (or one filename with that prefix). It unzips the project, compiles a debug APK, and uploads a downloadable artifact named `Dutt-Bavani-APK`.

To start in a new repository:
1. Upload **exactly one** `Dutt_Bavani_Android_Project.zip` to the root of the `main` branch.
2. Create `.github/workflows/build-dutt-bavani.yml` in GitHub and paste the separate build workflow file provided with the ZIP.
3. Commit to `main`, then visit **Actions → Build Dutt Bavani APK** and select the successful run.
4. Download **Dutt-Bavani-APK** artifact, unzip it and install `app-debug.apk` from Android Files (not from inside a ZIP viewer).

If the ZIP was renamed on upload, the workflow accepts e.g. `Dutt_Bavani_Android_Project (2).zip` as long as there is *only one matching ZIP*.

This ZIP is **source code**, not a compiled APK. The APK is built by Android Studio or the GitHub workflow.

**Package:** `com.gauravkharva.duttbavani`.
